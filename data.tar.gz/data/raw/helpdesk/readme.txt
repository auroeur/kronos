The event log concerns the ticketing management process of the Help desk of an Italian software company.

These are the log details:
21348 events
4580  cases
14 	  activities

In the following the list of attributes with their mean:
Case ID: the case identifier
Activity: the activity name
Resource: the resource who performed the action
Complete Timestamp: the timestamp of the event. Format: YYYY/MM/DD hh:mm:ss.sss
Variant: case variant
Variant index: case variant in integer format
seriousness: a seriousness level for the ticket
customer: name of the customer
product: name of the product
responsible_section: name of the responsible section
seriousness_2: a sub-seriousness level
service_level: level of the service
service_type: type of the service
support_section: name of the support section
workgroup: name of the workgroup